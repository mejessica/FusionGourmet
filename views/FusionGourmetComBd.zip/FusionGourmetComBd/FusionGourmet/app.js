const express = require("express")
const request = require("request")
const axios = require("axios")
const ejs = require("ejs")
const app = express()
const path = require("path")
const passport = require("passport")
const LocalStrategy = require("passport-local")
const expressSession = require("express-session")
const methodOverride = require('method-override')
app.use(methodOverride('_method'))
const User = require("./models/user")
const favRecipe = require("./models/favRecipes")


const key_api = "d62185cdf2fa4e5c90a34f61cdf2c437"

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(express.static(path.join(__dirname, "public")))
app.use(express.urlencoded({ extended: false }))

app.get('/', (req, res) => {
    res.render('home')
})


app.get('/search', (req, res) => {
    res.render('results')
})

app.post('/search', async (req, res) => {

    const { query } = req.body;
    const response = await axios.get(`https://api.spoonacular.com/recipes/complexSearch?query=${query}&apiKey=${key_api}`)
    const recipes = response.data.results;
    res.render('results', { recipes })
})


app.get('/recipe/:id', async (req, res) => {
    const { id } = req.params;
    const response = await axios.get(`https://api.spoonacular.com/recipes/${id}/information?apiKey=${key_api}`)
    const recipe = response.data;

    res.render('recipe', { recipe })
})


/*Login and register*/

app.use(express.urlencoded({ extended: true }))
app.use(expressSession({
    secret: "profile",
    resave: false,
    saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
passport.use(new LocalStrategy(User.authenticate()))
passport.serializeUser(User.serializeUser())
passport.deserializeUser(User.deserializeUser())


app.get('/register', (req, res) => {
    res.render('register')
})

app.post("/registerSubmit", (req, res) => {
    User.register(new User(
        {
            name: req.body.username,
            email: req.body.email
        }
    ), req.body.password, (err, user) => {
        if (err) {
            console.log(err)
            res.render("register")
        } else {
            passport.authenticate("local")(req, res, () => {
                res.redirect("/login")
            })
        }
    })
})

const isLoggedIn = (req, res, next) => {
    if (req.isAuthenticated()) {
        return next()
    }
    res.redirect('/login')
}

app.get('/infoProfile', isLoggedIn, (req, res) => {
    res.render('recipes/infoProfile')
})

app.get('/login', (req, res) => {
    res.render('login')
})

app.post('/login',
    passport.authenticate('local', { failureRedirect: '/login', failureMessage: true }),
    function (req, res) {
        res.redirect('/infoProfile');
    });

app.get('/logout', (req, res) => {
    req.logout(() => { console.log('Deslogado') })
    res.redirect('/')
})

/*Add fav no banco*/

app.post('/infoProfile/:id', (req, res) => {
    const { id } = req.params
    if(recipe.totalItems > 0){
        for(item of recipe.items){
            if(item.id == id){
                const receitaFavoritada = await favRecipe.find({ title: recipe.title })
                if(receitaFavoritada.length == 0){
                    const novaFavorita = new favRecipe({title: recipe.title})
                    await novaFavorita.save()
                    console.log("Receita salva!")
                } else{
                    console.log("Receita já está salva na lista de favoritos.")
                }
            }
        }
       
    }
   
})

app.get('/infoProfile/:id', async(req, res) => {
    const {id} = req.params
    const recipe = await favRecipe.findById(id)
    if (recipe)
        res.render('recipes/show', {recipe})
    else
        res.send('A receita não foi encontrada.')
})

app.delete('/infoProfile/:id', async(req, res) => {
    const {id} = req.params
    await favRecipe.findByIdAndDelete(id)
    res.redirect('/infoProfile')
})


app.listen(3000, () => {
    console.log("servidor ligado na porta 3000")
})