const mongoose = require("mongoose")
const {mongoose} = require('../db')

const recipeSchema = new mongoose.Schema({
    title:String,
})

const favRecipe = mongoose.model("favRecipe", recipeSchema)

module.exports = favRecipe
