# Fusion Gourmet

![Badge em Desenvolvimento](http://img.shields.io/static/v1?label=STATUS&message=EM%20DESENVOLVIMENTO&color=GREEN&style=for-the-badge)

## Como está ficando

![FusionGourmet (1)](https://github.com/mejessica/FusionGourmet/assets/82670472/cd79f9de-9a87-41a7-8f3f-cb9f14b36e9b)
